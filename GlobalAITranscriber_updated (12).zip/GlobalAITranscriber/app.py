import multiprocessing
import streamlit as st

from ui.theme import apply_theme
from ui.topbar import render_topbar
from ui.auth_page import render_auth_page
from ui.workflow_ui import render_workflow

# Required on Windows when using multiprocessing with the "spawn"
# method (the default on Windows). Without this, child processes
# launched by BrowserProcess will try to re-run the Streamlit app
# instead of the worker function.
if __name__ == "__main__":
    multiprocessing.freeze_support()

st.set_page_config(
    page_title="Global AI Transcriber",
    page_icon="🌍",
    layout="centered",
)

if "theme" not in st.session_state:
    st.session_state.theme = "light"

if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if "stage" not in st.session_state:
    st.session_state.stage = "idle"

apply_theme()

if not st.session_state.logged_in:
    render_auth_page()
else:
    render_topbar()
    render_workflow()
